
var api_key = "62be1c8445c92c28e5b36f548c069f69",
	api_secret = "371780d53d282c42b3e50229df3df313",
	session_id,
	current_song,
	scrobble_timer,
	cancelScrobble = false,
	lastSimilarSongsMetadata = {},
	tagCountThreshold = 50,
	songTags = localStorage["songTags"];
	
if(typeof(songTags) === "undefined") {
	songTags = {};
} else {
	songTags = JSON.parse(songTags);
}

saveVersionFromManifest()

chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
	if (request.method == "getSession") {
		sendResponse(localStorage['lastfm-session-token']);
	} else if (request.method == "createSession") {
		create_session();
	} else if (request.method == "nowPlaying") {
		nowPlaying(request.songObj,request.session_token,request.scrobbleEnabled);
	} else if (request.method == "setCancelScrobble") {
		setCancelScrobble(request.shouldCancel);
	} else if (request.method == "findSimilarSongs") {
		find_similar_songs(request.songInformation, sendResponse);
	} else if (request.method == "clearLastFMData") {
		localStorage.removeItem("lastfm-token")
		localStorage.removeItem("lastfm-session-token")
		sendResponse()
	} else if (request.method == "getManifestVersion") {
		sendResponse(localStorage.manifestVersion)
	} else {
		console.warn("Snubbing... Unknown method: " + request.method)
		sendResponse(); // snub them.
	}
});

function saveVersionFromManifest() {
	$.get(chrome.extension.getURL('manifest.json'),function(data) {
		localStorage.manifestVersion = data.version
	},'json')
}

function nowPlaying(songObj,session_token,scrobbleEnabled) {
	current_song = songObj;
	//console.debug("In nowPlaying with session_token",session_token);
	// console.log("lastfm-session-token", session_token);
	timestamp = Math.round((new Date()).getTime() / 1000);

	var method = 'POST';
	var api_call ='track.updateNowPlaying';
	var url = 'http://ws.audioscrobbler.com/2.0/';

	var artist = songObj.artist;
	var track = songObj.song;
	var length = songObj.length;
	var album = songObj.album;
	var scrobbleIn = Math.min(240,length/2);

	window.clearTimeout(scrobble_timer);
	//console.debug("background::nowPlaying: Setting up a scrobble to happen in",scrobbleIn,"seconds.")
	scrobble_timer = window.setTimeout(
		function(){
			//console.debug("Calling scrobble from wthin nowPlaying. scrobbleEnabled:",scrobbleEnabled)
			if (scrobbleEnabled) scrobble(songObj, session_token);
		}, scrobbleIn*1000);

	//console.log("Creating sig from: "+"artist"+artist+"api_key"+api_key+"method"+api_call+"sk"+session_token+"timestamp"+timestamp+"track"+track+api_secret);
	var methodSignature = "album" + album + "api_key" + api_key + "artist" + artist + "length" + length + "method" + api_call + "sk" + session_token + "timestamp" + timestamp + "track" + track+api_secret;
	// console.log(methodSignature);
	api_sig = hex_md5(methodSignature);

	var params = {
		"album" : album,
		"api_key" : api_key,
		"artist": artist,
		"api_sig": api_sig,
		"length": length,
		"sk": session_token,
		"timestamp": timestamp,
		"track": track,
		"format":"json"
	};

	var xhr = new XMLHttpRequest();
	xhr.open(method, url + '?' + 'method=' + api_call + '&' + stringify(params), true);

	 xhr.onreadystatechange = function(data) {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				console.log("Received data: "+xhr.responseText);
			}
		}
	};

	xhr.send();
	//console.log("Made XHR request: "+url + '?method=' + api_call + '&' + stringify(params));

}

function setCancelScrobble(shouldCancel) {
	cancelScrobble = shouldCancel;
}


function scrobble(songObj,session_token) {
	console.log("In scrobble with track",songObj.artist,songObj.song,"and session_token",session_token);
	// console.log("cancel?", cancelScrobble);
	if(cancelScrobble) {
		//console.debug("Canceling Scrobble- track was voted lame.");
	} else {
		timestamp = Math.round((new Date()).getTime() / 1000);

		var method = 'POST';
		var api_call ='track.scrobble';
	  	var url = 'http://ws.audioscrobbler.com/2.0/';

		var artist = songObj.artist;
		var track = songObj.song;
		var length = songObj.length;
		var album = songObj.album;
		//console.log("Creating sig from: "+"artist"+artist+"api_key"+api_key+"method"+api_call+"sk"+session_token+"timestamp"+timestamp+"track"+track+api_secret);

		api_sig = hex_md5("album" + album + "api_key"+api_key+"artist"+artist+"method"+api_call+"sk"+session_token+"timestamp"+timestamp+"track"+track+api_secret);

		var params = {
			"album" : album,
			"api_key" : api_key,
			"artist": artist,
			"api_sig": api_sig,
			"sk": session_token,
			"timestamp": timestamp,
			"track": track,
			"format":"json"
		};

		var xhr = new XMLHttpRequest();
		xhr.open(method, url + '?' + 'method=' + api_call + '&' + stringify(params), true);

		 xhr.onreadystatechange = function(data) {
			if (xhr.readyState == 4) {
				if (xhr.status == 200) {
					console.log("scrobble: Received data: "+xhr.responseText);
				}
			}
 		};

 	  	xhr.send();
		//console.log("Made XHR request: "+url + '?method=' + api_call + '&' + stringify(params));
	}
	
}

function create_session() {
	//console.debug("In create_session")
	timestamp = new Date().getTime();
	var method = 'GET';
	var api_call ='auth.getSession';
  	var url = 'http://ws.audioscrobbler.com/2.0/';
	var token = localStorage['lastfm-token'];
	// console.log("api_key"+api_key+api_call+"token"+token+api_secret);
	
	api_sig = hex_md5("api_key"+api_key+"method"+api_call+"token"+token+api_secret);

	var params = {
		"api_key" : api_key,
		"api_sig": api_sig,
		"token": token,
		"format":"json"
	};

	var xhr = new XMLHttpRequest();
	xhr.open(method, url + '?' + 'method=' + api_call + '&' + stringify(params), true);
	
	 xhr.onreadystatechange = function(data) {
		
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				session_response = JSON.parse(xhr.responseText);
				//console.debug("create_session: Received data: "+ xhr.responseText);
				localStorage['lastfm-session-token'] = session_response.session.key;				
			}
		}
	};
			 
  	xhr.send();

	//console.log("Made XHR request: "+url + '?method=' + api_call + '&' + stringify(params));
}

function find_similar_songs(songInformation,sendResponse) {
	var currentSong = songInformation.currentSong
	//console.debug("find_similar_songs with songLog:",songInformation.songLog)
	
	var songLog = TTExBGUtils.prepareSongLogForSimilarSongSearch(songInformation.songLog)
	// console.log("songLog", songLog);

	var songLogPromise = getSimilarSongsFromSongLog(songLog)

	var currentSongPromise = getSimilarSongsFromLastFM(currentSong)

	$.when(currentSongPromise, songLogPromise).done(function(similarToCurrentSong,similarToSongLog) {
		var result = {}
		result.similarToCurrentSong = similarToCurrentSong
		result.similarToSongLog = similarToSongLog
		sendResponse(JSON.stringify(result))
	});
}

function randomizeSongs(songs,numberOfResults) {
	var randomComparer = function(){ return 0.5 - Math.random() }
	var songsClone = songs.slice(0)
	songsClone.sort(randomComparer)

	if (songsClone.length > numberOfResults) {
		songsClone.splice(numberOfResults)
	}
	return songsClone
}

function getSimilarSongsFromSongLog(songLog,deferred,loggingIndent) {
	loggingIndent = loggingIndent || "";
	var firstTime = false
	if (!deferred) {
		//console.debug(loggingIndent,"Entering getSimilarSongsFromSongLog for the first time. songLog length is",songLog.length)
		deferred = new $.Deferred();
		firstTime = true
	} else {
		//console.debug(loggingIndent,"Entering getSimilarSongsFromSongLog. songLog length is",songLog.length)
	}

	if (songLog.length == 0) {
		//console.debug(loggingIndent,"songLog is empty, resolving the deferred object with an empty array.");
		deferred.resolve([])
	} else {
		var song = songLog.splice(0,1)[0]
		//console.debug(loggingIndent,"getSimilarSongsFromSongLog: Processing song",song);
	    //for each song, get similar songs.
		var eachSongPromise = getSimilarSongsFromLastFM(song.metadata,27);

		eachSongPromise.done(function(similarSongs) {
			if (similarSongs.length < 5) {
				//console.info(loggingIndent,"getSimilarSongsFromSongLog: Not enough songs (",similarSongs.length,") found for",song,"Recursing down...")
				getSimilarSongsFromSongLog(songLog,deferred,loggingIndent + '  ')
			} else {
				//console.debug(loggingIndent,"getSimilarSongsFromSongLog: Randomizing",similarSongs.length ,"similar songs.",similarSongs)
				var randomSongs = randomizeSongs(similarSongs,8)
				//console.debug(loggingIndent,"getSimilarSongsFromSongLog: Resolving deferred object with similar songs:",similarSongs)
				deferred.resolve(randomSongs)
			}
		});
	}

	if (firstTime) {
		return deferred.promise()
	} else {
		return
	}
}

function getSimilarSongsFromLastFM(songMetadata,songLimit) {
	var dfd = new $.Deferred();

	if (!songLimit) songLimit = 10;
	
	var params = {
		    "method" : "track.getsimilar",
		    "artist" : songMetadata.artist,
		    "track" : songMetadata.song,
		    "api_key" : api_key,
			"limit" : songLimit + '',
		    "format" : "json"
		},
		url = 'http://ws.audioscrobbler.com/2.0/';

	var jqXHR = $.get(url,params,function(data) {
		var songsByOtherArtists = [];
		if (data.error == null && $.type(data.similartracks.track) !== "string") { //sometimes last.fm returns weird data.
			$.each(data.similartracks.track, function(index, trackInfo) {
				if (trackInfo.artist.name.toLowerCase() != songMetadata.artist.toLowerCase()) {
					songsByOtherArtists.push(trackInfo);
				}
			});
		}

		//console.debug("getSimilarSongsFromLastFM: resolving deferred with songs:",songsByOtherArtists)
		dfd.resolve(songsByOtherArtists)
	});

	jqXHR.error(function(xhr, textStatus, errorThrown) {
		console.warn("Background::getSimilarSongsFromLastFM: An error occurred while getting similar songs:",errorThrown,"The text status was:",textStatus)
		dfd.resolve([])
	});

	return dfd.promise()
}

function find_top_tags(song,sendResponse) {
	var songMetadata = song.metadata,
		params = {
		    "method" : "track.getTopTags",
		    "artist" : songMetadata.artist,
		    "track" : songMetadata.song,
		    "api_key" : api_key,
			"autocorrect" : "1",
		    "format" : "json"
		},
		url = 'http://ws.audioscrobbler.com/2.0/';
	if(typeof(songTags[song.fileId]) !== "undefined") {
		sendResponse(JSON.stringify(songTags[song.fileId]));
	} else {
		// console.log("Not found locally, requesting tags from last.fm");
		var jqXHR = $.get(url,params,function(data) {
			var topSongTags = [],
				type = (typeof(data.toptags) !== "undefined" && typeof(data.toptags.tag) !== "undefined")?$.type(data.toptags.tag):"undefined";
			if (type !== "string" && type !== "undefined") { //sometimes last.fm returns weird data.
				$.each(data.toptags.tag, function(index, tagInfo) {
					if(tagInfo.count >= tagCountThreshold) {
						topSongTags.push(tagInfo.name);
					}
				});
			}
		
			// console.log("find_top_tags: Sending",topSongTags,"to the content script.");
			sendResponse(JSON.stringify(topSongTags));
		
			songTags[song.fileId] = topSongTags;
			localStorage["songTags"] = JSON.stringify(songTags);
		});

		jqXHR.error(function(xhr, textStatus, errorThrown) {
			console.warn("Background::find_top_tags: An error occured while getting top tags:",errorThrown,"The text status was:",textStatus)
			songTags[song.fileId] = [];
			localStorage["songTags"] = JSON.stringify(songTags);
		});
	}
}

//////////Utils///////////

/*
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */

/*
 * Configurable variables. You may need to tweak these to be compatible with
 * the server-side, but the defaults work in most cases.
 */
var hexcase = 0;   /* hex output format. 0 - lowercase; 1 - uppercase        */
var b64pad  = "";  /* base-64 pad character. "=" for strict RFC compliance   */

/*
 * These are the functions you'll usually want to call
 * They take string arguments and return either hex or base-64 encoded strings
 */
function hex_md5(s)    { return rstr2hex(rstr_md5(str2rstr_utf8(s))); }
function b64_md5(s)    { return rstr2b64(rstr_md5(str2rstr_utf8(s))); }
function any_md5(s, e) { return rstr2any(rstr_md5(str2rstr_utf8(s)), e); }
function hex_hmac_md5(k, d)
  { return rstr2hex(rstr_hmac_md5(str2rstr_utf8(k), str2rstr_utf8(d))); }
function b64_hmac_md5(k, d)
  { return rstr2b64(rstr_hmac_md5(str2rstr_utf8(k), str2rstr_utf8(d))); }
function any_hmac_md5(k, d, e)
  { return rstr2any(rstr_hmac_md5(str2rstr_utf8(k), str2rstr_utf8(d)), e); }

/*
 * Perform a simple self-test to see if the VM is working
 */
function md5_vm_test()
{
  return hex_md5("abc").toLowerCase() == "900150983cd24fb0d6963f7d28e17f72";
}

/*
 * Calculate the MD5 of a raw string
 */
function rstr_md5(s)
{
  return binl2rstr(binl_md5(rstr2binl(s), s.length * 8));
}

/*
 * Calculate the HMAC-MD5, of a key and some data (raw strings)
 */
function rstr_hmac_md5(key, data)
{
  var bkey = rstr2binl(key);
  if(bkey.length > 16) bkey = binl_md5(bkey, key.length * 8);

  var ipad = Array(16), opad = Array(16);
  for(var i = 0; i < 16; i++)
  {
    ipad[i] = bkey[i] ^ 0x36363636;
    opad[i] = bkey[i] ^ 0x5C5C5C5C;
  }

  var hash = binl_md5(ipad.concat(rstr2binl(data)), 512 + data.length * 8);
  return binl2rstr(binl_md5(opad.concat(hash), 512 + 128));
}

/*
 * Convert a raw string to a hex string
 */
function rstr2hex(input)
{
  try { hexcase } catch(e) { hexcase=0; }
  var hex_tab = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
  var output = "";
  var x;
  for(var i = 0; i < input.length; i++)
  {
    x = input.charCodeAt(i);
    output += hex_tab.charAt((x >>> 4) & 0x0F)
           +  hex_tab.charAt( x        & 0x0F);
  }
  return output;
}

/*
 * Convert a raw string to a base-64 string
 */
function rstr2b64(input)
{
  try { b64pad } catch(e) { b64pad=''; }
  var tab = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var output = "";
  var len = input.length;
  for(var i = 0; i < len; i += 3)
  {
    var triplet = (input.charCodeAt(i) << 16)
                | (i + 1 < len ? input.charCodeAt(i+1) << 8 : 0)
                | (i + 2 < len ? input.charCodeAt(i+2)      : 0);
    for(var j = 0; j < 4; j++)
    {
      if(i * 8 + j * 6 > input.length * 8) output += b64pad;
      else output += tab.charAt((triplet >>> 6*(3-j)) & 0x3F);
    }
  }
  return output;
}

/*
 * Convert a raw string to an arbitrary string encoding
 */
function rstr2any(input, encoding)
{
  var divisor = encoding.length;
  var i, j, q, x, quotient;

  /* Convert to an array of 16-bit big-endian values, forming the dividend */
  var dividend = Array(Math.ceil(input.length / 2));
  for(i = 0; i < dividend.length; i++)
  {
    dividend[i] = (input.charCodeAt(i * 2) << 8) | input.charCodeAt(i * 2 + 1);
  }

  /*
   * Repeatedly perform a long division. The binary array forms the dividend,
   * the length of the encoding is the divisor. Once computed, the quotient
   * forms the dividend for the next step. All remainders are stored for later
   * use.
   */
  var full_length = Math.ceil(input.length * 8 /
                                    (Math.log(encoding.length) / Math.log(2)));
  var remainders = Array(full_length);
  for(j = 0; j < full_length; j++)
  {
    quotient = Array();
    x = 0;
    for(i = 0; i < dividend.length; i++)
    {
      x = (x << 16) + dividend[i];
      q = Math.floor(x / divisor);
      x -= q * divisor;
      if(quotient.length > 0 || q > 0)
        quotient[quotient.length] = q;
    }
    remainders[j] = x;
    dividend = quotient;
  }

  /* Convert the remainders to the output string */
  var output = "";
  for(i = remainders.length - 1; i >= 0; i--)
    output += encoding.charAt(remainders[i]);

  return output;
}

/*
 * Encode a string as utf-8.
 * For efficiency, this assumes the input is valid utf-16.
 */
function str2rstr_utf8(input)
{
  var output = "";
  var i = -1;
  var x, y;

  while(++i < input.length)
  {
    /* Decode utf-16 surrogate pairs */
    x = input.charCodeAt(i);
    y = i + 1 < input.length ? input.charCodeAt(i + 1) : 0;
    if(0xD800 <= x && x <= 0xDBFF && 0xDC00 <= y && y <= 0xDFFF)
    {
      x = 0x10000 + ((x & 0x03FF) << 10) + (y & 0x03FF);
      i++;
    }

    /* Encode output as utf-8 */
    if(x <= 0x7F)
      output += String.fromCharCode(x);
    else if(x <= 0x7FF)
      output += String.fromCharCode(0xC0 | ((x >>> 6 ) & 0x1F),
                                    0x80 | ( x         & 0x3F));
    else if(x <= 0xFFFF)
      output += String.fromCharCode(0xE0 | ((x >>> 12) & 0x0F),
                                    0x80 | ((x >>> 6 ) & 0x3F),
                                    0x80 | ( x         & 0x3F));
    else if(x <= 0x1FFFFF)
      output += String.fromCharCode(0xF0 | ((x >>> 18) & 0x07),
                                    0x80 | ((x >>> 12) & 0x3F),
                                    0x80 | ((x >>> 6 ) & 0x3F),
                                    0x80 | ( x         & 0x3F));
  }
  return output;
}

/*
 * Encode a string as utf-16
 */
function str2rstr_utf16le(input)
{
  var output = "";
  for(var i = 0; i < input.length; i++)
    output += String.fromCharCode( input.charCodeAt(i)        & 0xFF,
                                  (input.charCodeAt(i) >>> 8) & 0xFF);
  return output;
}

function str2rstr_utf16be(input)
{
  var output = "";
  for(var i = 0; i < input.length; i++)
    output += String.fromCharCode((input.charCodeAt(i) >>> 8) & 0xFF,
                                   input.charCodeAt(i)        & 0xFF);
  return output;
}

/*
 * Convert a raw string to an array of little-endian words
 * Characters >255 have their high-byte silently ignored.
 */
function rstr2binl(input)
{
  var output = Array(input.length >> 2);
  for(var i = 0; i < output.length; i++)
    output[i] = 0;
  for(var i = 0; i < input.length * 8; i += 8)
    output[i>>5] |= (input.charCodeAt(i / 8) & 0xFF) << (i%32);
  return output;
}

/*
 * Convert an array of little-endian words to a string
 */
function binl2rstr(input)
{
  var output = "";
  for(var i = 0; i < input.length * 32; i += 8)
    output += String.fromCharCode((input[i>>5] >>> (i % 32)) & 0xFF);
  return output;
}

/*
 * Calculate the MD5 of an array of little-endian words, and a bit length.
 */
function binl_md5(x, len)
{
  /* append padding */
  x[len >> 5] |= 0x80 << ((len) % 32);
  x[(((len + 64) >>> 9) << 4) + 14] = len;

  var a =  1732584193;
  var b = -271733879;
  var c = -1732584194;
  var d =  271733878;

  for(var i = 0; i < x.length; i += 16)
  {
    var olda = a;
    var oldb = b;
    var oldc = c;
    var oldd = d;

    a = md5_ff(a, b, c, d, x[i+ 0], 7 , -680876936);
    d = md5_ff(d, a, b, c, x[i+ 1], 12, -389564586);
    c = md5_ff(c, d, a, b, x[i+ 2], 17,  606105819);
    b = md5_ff(b, c, d, a, x[i+ 3], 22, -1044525330);
    a = md5_ff(a, b, c, d, x[i+ 4], 7 , -176418897);
    d = md5_ff(d, a, b, c, x[i+ 5], 12,  1200080426);
    c = md5_ff(c, d, a, b, x[i+ 6], 17, -1473231341);
    b = md5_ff(b, c, d, a, x[i+ 7], 22, -45705983);
    a = md5_ff(a, b, c, d, x[i+ 8], 7 ,  1770035416);
    d = md5_ff(d, a, b, c, x[i+ 9], 12, -1958414417);
    c = md5_ff(c, d, a, b, x[i+10], 17, -42063);
    b = md5_ff(b, c, d, a, x[i+11], 22, -1990404162);
    a = md5_ff(a, b, c, d, x[i+12], 7 ,  1804603682);
    d = md5_ff(d, a, b, c, x[i+13], 12, -40341101);
    c = md5_ff(c, d, a, b, x[i+14], 17, -1502002290);
    b = md5_ff(b, c, d, a, x[i+15], 22,  1236535329);

    a = md5_gg(a, b, c, d, x[i+ 1], 5 , -165796510);
    d = md5_gg(d, a, b, c, x[i+ 6], 9 , -1069501632);
    c = md5_gg(c, d, a, b, x[i+11], 14,  643717713);
    b = md5_gg(b, c, d, a, x[i+ 0], 20, -373897302);
    a = md5_gg(a, b, c, d, x[i+ 5], 5 , -701558691);
    d = md5_gg(d, a, b, c, x[i+10], 9 ,  38016083);
    c = md5_gg(c, d, a, b, x[i+15], 14, -660478335);
    b = md5_gg(b, c, d, a, x[i+ 4], 20, -405537848);
    a = md5_gg(a, b, c, d, x[i+ 9], 5 ,  568446438);
    d = md5_gg(d, a, b, c, x[i+14], 9 , -1019803690);
    c = md5_gg(c, d, a, b, x[i+ 3], 14, -187363961);
    b = md5_gg(b, c, d, a, x[i+ 8], 20,  1163531501);
    a = md5_gg(a, b, c, d, x[i+13], 5 , -1444681467);
    d = md5_gg(d, a, b, c, x[i+ 2], 9 , -51403784);
    c = md5_gg(c, d, a, b, x[i+ 7], 14,  1735328473);
    b = md5_gg(b, c, d, a, x[i+12], 20, -1926607734);

    a = md5_hh(a, b, c, d, x[i+ 5], 4 , -378558);
    d = md5_hh(d, a, b, c, x[i+ 8], 11, -2022574463);
    c = md5_hh(c, d, a, b, x[i+11], 16,  1839030562);
    b = md5_hh(b, c, d, a, x[i+14], 23, -35309556);
    a = md5_hh(a, b, c, d, x[i+ 1], 4 , -1530992060);
    d = md5_hh(d, a, b, c, x[i+ 4], 11,  1272893353);
    c = md5_hh(c, d, a, b, x[i+ 7], 16, -155497632);
    b = md5_hh(b, c, d, a, x[i+10], 23, -1094730640);
    a = md5_hh(a, b, c, d, x[i+13], 4 ,  681279174);
    d = md5_hh(d, a, b, c, x[i+ 0], 11, -358537222);
    c = md5_hh(c, d, a, b, x[i+ 3], 16, -722521979);
    b = md5_hh(b, c, d, a, x[i+ 6], 23,  76029189);
    a = md5_hh(a, b, c, d, x[i+ 9], 4 , -640364487);
    d = md5_hh(d, a, b, c, x[i+12], 11, -421815835);
    c = md5_hh(c, d, a, b, x[i+15], 16,  530742520);
    b = md5_hh(b, c, d, a, x[i+ 2], 23, -995338651);

    a = md5_ii(a, b, c, d, x[i+ 0], 6 , -198630844);
    d = md5_ii(d, a, b, c, x[i+ 7], 10,  1126891415);
    c = md5_ii(c, d, a, b, x[i+14], 15, -1416354905);
    b = md5_ii(b, c, d, a, x[i+ 5], 21, -57434055);
    a = md5_ii(a, b, c, d, x[i+12], 6 ,  1700485571);
    d = md5_ii(d, a, b, c, x[i+ 3], 10, -1894986606);
    c = md5_ii(c, d, a, b, x[i+10], 15, -1051523);
    b = md5_ii(b, c, d, a, x[i+ 1], 21, -2054922799);
    a = md5_ii(a, b, c, d, x[i+ 8], 6 ,  1873313359);
    d = md5_ii(d, a, b, c, x[i+15], 10, -30611744);
    c = md5_ii(c, d, a, b, x[i+ 6], 15, -1560198380);
    b = md5_ii(b, c, d, a, x[i+13], 21,  1309151649);
    a = md5_ii(a, b, c, d, x[i+ 4], 6 , -145523070);
    d = md5_ii(d, a, b, c, x[i+11], 10, -1120210379);
    c = md5_ii(c, d, a, b, x[i+ 2], 15,  718787259);
    b = md5_ii(b, c, d, a, x[i+ 9], 21, -343485551);

    a = safe_add(a, olda);
    b = safe_add(b, oldb);
    c = safe_add(c, oldc);
    d = safe_add(d, oldd);
  }
  return Array(a, b, c, d);
}

/*
 * These functions implement the four basic operations the algorithm uses.
 */
function md5_cmn(q, a, b, x, s, t)
{
  return safe_add(bit_rol(safe_add(safe_add(a, q), safe_add(x, t)), s),b);
}
function md5_ff(a, b, c, d, x, s, t)
{
  return md5_cmn((b & c) | ((~b) & d), a, b, x, s, t);
}
function md5_gg(a, b, c, d, x, s, t)
{
  return md5_cmn((b & d) | (c & (~d)), a, b, x, s, t);
}
function md5_hh(a, b, c, d, x, s, t)
{
  return md5_cmn(b ^ c ^ d, a, b, x, s, t);
}
function md5_ii(a, b, c, d, x, s, t)
{
  return md5_cmn(c ^ (b | (~d)), a, b, x, s, t);
}

/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
 * to work around bugs in some JS interpreters.
 */
function safe_add(x, y)
{
  var lsw = (x & 0xFFFF) + (y & 0xFFFF);
  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return (msw << 16) | (lsw & 0xFFFF);
}

/*
 * Bitwise rotate a 32-bit number to the left.
 */
function bit_rol(num, cnt)
{
  return (num << cnt) | (num >>> (32 - cnt));
}

function stringify(parameters) {
  var params = [];
  for(var p in parameters) {
    params.push(encodeURIComponent(p) + '=' +
                encodeURIComponent(parameters[p]));
  }
  return params.join('&');
};

function htmlspecialchars_decode (string, quote_style) {
    // Convert special HTML entities back to characters  
    // 
    // version: 1103.1210
    // discuss at: http://phpjs.org/functions/htmlspecialchars_decode
    // +   original by: Mirek Slugen
    // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   bugfixed by: Mateusz "loonquawl" Zalega
    // +      input by: ReverseSyntax
    // +      input by: Slawomir Kaniecki
    // +      input by: Scott Cariss
    // +      input by: Francois
    // +   bugfixed by: Onno Marsman
    // +    revised by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   bugfixed by: Brett Zamir (http://brett-zamir.me)
    // +      input by: Ratheous
    // +      input by: Mailfaker (http://www.weedem.fr/)
    // +      reimplemented by: Brett Zamir (http://brett-zamir.me)
    // +    bugfixed by: Brett Zamir (http://brett-zamir.me)
    // *     example 1: htmlspecialchars_decode("<p>this -&gt; &quot;</p>", 'ENT_NOQUOTES');
    // *     returns 1: '<p>this -> &quot;</p>'
    // *     example 2: htmlspecialchars_decode("&amp;quot;");
    // *     returns 2: '&quot;'
    var optTemp = 0,
        i = 0,
        noquotes = false;
    if (typeof quote_style === 'undefined') {
        quote_style = 2;
    }
    string = string.toString().replace(/&lt;/g, '<').replace(/&gt;/g, '>');
    var OPTS = {
        'ENT_NOQUOTES': 0,
        'ENT_HTML_QUOTE_SINGLE': 1,
        'ENT_HTML_QUOTE_DOUBLE': 2,
        'ENT_COMPAT': 2,
        'ENT_QUOTES': 3,
        'ENT_IGNORE': 4
    };
    if (quote_style === 0) {
        noquotes = true;
    }
    if (typeof quote_style !== 'number') { // Allow for a single string or an array of string flags
        quote_style = [].concat(quote_style);
        for (i = 0; i < quote_style.length; i++) {
            // Resolve string input to bitwise e.g. 'PATHINFO_EXTENSION' becomes 4
            if (OPTS[quote_style[i]] === 0) {
                noquotes = true;
            } else if (OPTS[quote_style[i]]) {
                optTemp = optTemp | OPTS[quote_style[i]];
            }
        }
        quote_style = optTemp;
    }
    if (quote_style & OPTS.ENT_HTML_QUOTE_SINGLE) {
        string = string.replace(/&#0*39;/g, "'"); // PHP doesn't currently escape if more than one 0, but it should
        // string = string.replace(/&apos;|&#x0*27;/g, "'"); // This would also be useful here, but not a part of PHP
    }
    if (!noquotes) {
        string = string.replace(/&quot;/g, '"');
    }
    // Put this in last place to avoid escape being double-decoded
    string = string.replace(/&amp;/g, '&');

    return string;
}